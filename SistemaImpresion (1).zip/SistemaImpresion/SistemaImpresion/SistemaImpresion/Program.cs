using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;

namespace SistemaImpresion
{
    class Program
    {
        private static readonly Stopwatch reloj = Stopwatch.StartNew();
        private static readonly object candadoConsola = new object();

        public static void Log(string mensaje)
        {
            lock (candadoConsola)
                Console.WriteLine($"{reloj.Elapsed.TotalSeconds,5:0.00}s  {mensaje}");
        }

        static void Main()
        {
         
            Impresora impresora = Impresora.Instancia;

            impresora.Configurar(3, new List<INotificador>
            {
                new NotificadorSms(),
                new NotificadorWhatsApp(),
                new NotificadorEmail()
            });

            Usuario[] usuarios =
            {
                new Usuario("Ana  ", 3, 6, 1),
                new Usuario("Beto ", 3, 6, 2),
                new Usuario("Carla", 3, 6, 3)
            };

            Thread hiloImpresora = new Thread(impresora.Ejecutar);
            hiloImpresora.Start();

            List<Thread> hilosUsuarios = new List<Thread>();
            foreach (Usuario u in usuarios) hilosUsuarios.Add(new Thread(u.Ejecutar));
            hilosUsuarios.ForEach(h => h.Start());

            hilosUsuarios.ForEach(h => h.Join());   
            impresora.Cerrar();                    
            hiloImpresora.Join();

            
            int esperado = 0;
            foreach (Usuario u in usuarios) esperado += u.Enviados;
            Console.WriteLine();
            Console.WriteLine($"Trabajos enviados: {esperado} | Impresos: {impresora.Impresos} | " +
                              (impresora.Impresos == esperado ? "OK" : "ERROR: se perdieron trabajos"));
        }
    }
}
