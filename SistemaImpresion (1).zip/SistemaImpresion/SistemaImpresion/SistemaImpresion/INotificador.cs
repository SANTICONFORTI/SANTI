namespace SistemaImpresion
{
 
    interface INotificador
    {
        void Notificar(string usuario, string documento);
    }
}
