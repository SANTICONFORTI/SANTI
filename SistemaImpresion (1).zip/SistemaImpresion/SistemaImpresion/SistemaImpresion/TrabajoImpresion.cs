namespace SistemaImpresion
{

    class TrabajoImpresion
    {
        public int Numero;
        public string Usuario;
        public string Documento;

        public override string ToString()
        {
            return $"#{Numero} \"{Documento}\" (de {Usuario})";
        }
    }
}
