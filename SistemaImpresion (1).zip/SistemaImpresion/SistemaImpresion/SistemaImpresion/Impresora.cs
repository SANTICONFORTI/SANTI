using System.Collections.Generic;
using System.Threading;

namespace SistemaImpresion
{

    class Impresora
    {
    
        private static Impresora instancia;
        private static readonly object candadoInstancia = new object();

        public static Impresora Instancia
        {
            get
            {
                if (instancia == null)
                {
                    lock (candadoInstancia)
                    {
                        if (instancia == null)
                            instancia = new Impresora();
                    }
                }
                return instancia;
            }
        }

        private Impresora() { }   

        private readonly Queue<TrabajoImpresion> cola = new Queue<TrabajoImpresion>();
        private readonly object candado = new object();
        private int capacidad = 5;
        private bool cerrada = false;
        private List<INotificador> notificadores = new List<INotificador>();

        public int Impresos { get; private set; }

      
        public void Configurar(int capacidad, List<INotificador> notificadores)
        {
            this.capacidad = capacidad;
            this.notificadores = notificadores;
        }

   
        public void EnviarTrabajo(TrabajoImpresion t)
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);

                while (cola.Count == capacidad)
                {
                    Program.Log($"{t.Usuario} espera: cola llena " + Ocupacion());
                    Monitor.Wait(candado);          
                }

                cola.Enqueue(t);
                Program.Log($"{t.Usuario} envia {t}  " + Ocupacion());
                Monitor.PulseAll(candado);          
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

      
        public TrabajoImpresion ObtenerSiguienteTrabajo()
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);

                while (cola.Count == 0 && !cerrada)
                    Monitor.Wait(candado);

                if (cola.Count == 0)                
                    return null;

                TrabajoImpresion t = cola.Dequeue();
                Monitor.PulseAll(candado);         
                return t;
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

       
        public void Ejecutar()
        {
            TrabajoImpresion t;
            while ((t = ObtenerSiguienteTrabajo()) != null)
            {
                try
                {
                    Imprimir(t);        
                    Notificar(t);     
                    Impresos++;
                }
                catch (System.Exception ex)
                {
                   
                    Program.Log($"ERROR al procesar {t}: {ex.Message}");
                }
            }
            Program.Log("Impresora: no hay mas trabajos, se apaga");
        }

        
        private void Imprimir(TrabajoImpresion t)
        {
            if (t == null)   
                throw new System.InvalidOperationException("No hay trabajo para imprimir");

            Program.Log($"Imprimiendo {t} ...");
            Thread.Sleep(600);
            Program.Log($"Listo {t}");
        }

        
        private void Notificar(TrabajoImpresion t)
        {
            foreach (INotificador n in notificadores)
                n.Notificar(t.Usuario, t.Documento);
        }

       
        public void Cerrar()
        {
            bool tomado = false;
            try
            {
                Monitor.Enter(candado, ref tomado);
                cerrada = true;
                Monitor.PulseAll(candado);         
            }
            finally
            {
                if (tomado) Monitor.Exit(candado);
            }
        }

   
        private string Ocupacion()
        {
            return "[" + new string('#', cola.Count)
                       + new string('.', capacidad - cola.Count) + "]";
        }
    }
}
